const images ={
    logo: require('./image/logo.png'),
    slide: require('./image/slide.jpg'),
    slide2: require('./image/slide2.jpeg'),
    slide3: require('./image/slide3.jpg'),
}
export default images;