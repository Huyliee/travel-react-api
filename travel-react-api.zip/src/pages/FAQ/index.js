function Faq() {
    return ( 
        <div style={{width:'100%'}}>
            <h1>Các chính sách của công ty</h1>
       </div>
     );
}

export default Faq;