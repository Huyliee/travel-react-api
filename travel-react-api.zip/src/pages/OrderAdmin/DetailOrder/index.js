import { Paper, Table, TableBody, TableCell, TableContainer, TableFooter, TableHead, TableRow } from "@mui/material";
import { useEffect, useState } from "react";
import {  useParams } from "react-router-dom";
import { detailTourOder } from "~/GlobalFunction/Api";
import styles from "~/pages/OrderAdmin/OrderAdmin.module.scss";
import classNames from "classnames/bind";
const cx = classNames.bind(styles);

function DetailOrder() {
    const [order,setOrder] = useState({});
    const {id} = useParams();
    useEffect(() => {
        if (id) {
          async function detailData() {
            const data = await detailTourOder(id);
            setOrder(data);
          }
          detailData();
        }
      }, [id]);
      const lengthPayment = order?.payment?.length;
    return (  
        <>  
            <h3>{order?.name}</h3>
            <h3>{order?.email}</h3>
            <h3>{order?.id_order_tour}</h3>
            <h3>{order?.order_time}</h3>
            <h3>{order?.phone}</h3>
            <TableContainer component={Paper} variant="outlined">
            <Table>
              <TableHead>
                <TableRow>
                <TableCell className={cx("headCell")}>Tên</TableCell>
                  <TableCell className={cx("headCell")}>Giới tính</TableCell>
                  <TableCell className={cx("headCell")}>CMND</TableCell>
                  <TableCell className={cx("headCell")}>Ngày sinh</TableCell>
                  <TableCell className={cx("headCell")}>Loại khách</TableCell>
                  <TableCell className={cx("headCell")}>Giá vé</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {order.detail_order &&
                  order.detail_order.map((item) => (
                    <TableRow>
                     <TableCell className={cx("bodyCell")} key={item.id}>
                        {item.name_customer}
                      </TableCell>
                      <TableCell className={cx("bodyCell")}>
                        {item.sex}
                      </TableCell>
                      <TableCell className={cx("bodyCell")}>
                        {item.CMND}
                      </TableCell>
                      <TableCell className={cx("bodyCell")}>
                        {item.birth}
                      </TableCell>
                      <TableCell className={cx("bodyCell")}>
                        {item.age}
                      </TableCell>
                      <TableCell >
                        {/* {item.age === "Người lớn"
                          ? (tour.adult_price ?? "").toLocaleString("vi-VN", {
                              style: "currency",
                              currency: "VND",
                            })
                          : (tour.child_price ?? "").toLocaleString("vi-VN", {
                              style: "currency",
                              currency: "VND",
                            })} */}
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
              <TableFooter>
                <TableRow>
                <TableCell className={cx("footCell")}>
                    Tổng giá tiền
                  </TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell className={cx("footCell")}>
                    {" "}
                    {(order?.total_price ?? "").toLocaleString("vi-VN", {
                      style: "currency",
                      currency: "VND",
                    })}
                  </TableCell>
                </TableRow>
                <TableRow>
                <TableCell className={cx("footCell")}>
                    Số tiền đã thanh toán
                  </TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell className={cx("footCell")}>
                    {order?.payment?.length > 0
                      ? (
                          order.payment[lengthPayment - 1].amount_paid ?? ""
                        ).toLocaleString("vi-VN", {
                          style: "currency",
                          currency: "VND",
                        })
                      : "0 đ"}
                  </TableCell>
                </TableRow>
                <TableRow>
                <TableCell className={cx("footCell")}>
                    Số tiền chưa thanh toán
                  </TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                  <TableCell className={cx("footCell")}>
                    {order?.payment?.length > 0
                      ? (
                          order.payment[lengthPayment - 1].amount_unpaid ?? ""
                        ).toLocaleString("vi-VN", {
                          style: "currency",
                          currency: "VND",
                        })
                      : (order?.total_price ?? "").toLocaleString(
                          "vi-VN",
                          {
                            style: "currency",
                            currency: "VND",
                          }
                        )}
                  </TableCell>
                </TableRow>
              </TableFooter>
            </Table>
          </TableContainer>
        </>
    );
}

export default DetailOrder;