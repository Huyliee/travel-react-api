// index.js
export const beepSound = require("~/pages/Tour/Filter/sound/beep.mp3");
